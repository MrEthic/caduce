package com.example.loginregister;

import android.os.Bundle;
import android.os.StrictMode;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

public class MainActivity extends AppCompatActivity {

    //jdbc:mysql://adresseip/nom_basededonnees
    //modifiez juste l'adresse ip, faite ipconfig sur windows
    //et regarder a la ligne adresse ipv4
    private  static final String url="jdbc:mysql://192.168.0.14:3306/ticko";
    //identifiant et mot de passe crée dans phpmyadmin, cliquez sur privileges
    //puis ajouter compte utilisateur, mettez l'identifiant et le même mot de passe
    //que dans ce fichier java
    //sinon vous verrez une erreur "exception, host refused to connect to this MariaDB"
    private  static  final  String user ="test";
    private  static  final  String pass="test";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        testDB();

        //modification du textview pour changer l'affichage du texte quand on se connecte
        //rate_id est l'id dans le textview issu du fichier main_activity.xml

        //String a="hello blitzkrank";
        //TextView data = (TextView)findViewById(R.id.rate_id);
        //data.setText(a);
    }
        public void testDB() {
            TextView tv = this.findViewById(R.id.rate_id);
            //permet d'accepter les connexions externes
            try{
                StrictMode.ThreadPolicy policy= new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);

                Class.forName("com.mysql.jdbc.Driver");
                Connection con = DriverManager.getConnection(url,user,pass);

                StringBuilder result = new StringBuilder("Vos mesures : \n");
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery("SELECT tension,humidite FROM `capteur` ORDER BY id_capteur DESC LIMIT 1");
                ResultSetMetaData rsmd = rs.getMetaData();
                /*while(rs.next()) {
                    //afficher les colonnes de chaque attribut
                    //cela va afficher  name [2] puis la tension[3], temperature[4], humidite[5]
                    result.append(rsmd.getColumnName(2)).append(": ").append(rs.getString(2)).append("\n");
                    result.append(rsmd.getColumnName(3)).append(": ").append(rs.getString(3)).append("\n");
                    result.append(rsmd.getColumnName(4)).append(": ").append(rs.getString(4)).append("\n");
                    result.append(rsmd.getColumnName(5)).append(": ").append(rs.getString(5)).append("\n");
                }*/
                while(rs.next()){
                    //colonne 1 et 2 de Getstring correspondent à la tension et l'humidité
                    //lorsqu'on fait la requête : SQL SELECT tension,humidite FROM `capteur` ORDER BY id_capteur DESC LIMIT 1
                    result.append("Tension :").append(rs.getString(1)).append(" (cmHg)").append("\n");
                    result.append("Humidité :").append(rs.getString(2)).append(" (°C)").append("\n");

                }

                tv.setText(result.toString());
            }
            catch (Exception e) {
                e.printStackTrace();
                tv.setText(e.toString());
            }
        } //Fin public void testDB()


} //fin de la classe mainactivity