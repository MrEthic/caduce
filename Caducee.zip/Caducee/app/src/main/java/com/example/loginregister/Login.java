package com.example.loginregister;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.vishnusivadas.advanced_httpurlconnection.PutData;

public class Login extends AppCompatActivity {
    // ne pas modifier les variables, ce sont les objets écrits en jaune dans activity_sign_up.xml
    //buttonLogin et non pas buttonSignUp pour se connecter !
    TextInputEditText textInputEditTextUsername, textInputEditTextPassword;
    Button buttonLogin;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //permet de charger  le contenu activity_login.xml
        setContentView(R.layout.activity_login);

        //equivalent à document.getelementbyid en javascript
        textInputEditTextUsername= findViewById(R.id.username);
        buttonLogin= findViewById(R.id.buttonLogin);
        textInputEditTextPassword= findViewById(R.id.password);
        progressBar= findViewById(R.id.progress);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //uniquement le nss et mot de passe nécessaires pour le login
                final String  Username, password;
                Username = String.valueOf(textInputEditTextUsername.getText());
                password = String.valueOf(textInputEditTextPassword.getText());

                //si on insère le mdp et le numero de secu social
                if (!Username.equals("") && !password.equals("")) {
                    //Début de la  ProgressBar (Setvisibility View.VISIBLE)
                    progressBar.setVisibility(View.VISIBLE);
                    Handler handler = new Handler();
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            //Lecture et écriture sur le lien URL
                            //2 élements de la table users issu de PHPmyAdmin nécessaires
                            //pour le login
                            String[] field = new String[2];
                            //attributs de la table user dans phpmyadmin
                            field[0] = "Nom";
                            field[1] = "password";
                            //Creating array for data
                            String[] data = new String[2];
                            data[0] = Username;
                            data[1] = password;
                            //adresse ip de mon  localhost : 192.168.0.14  http://localhost/LoginRegister/login.php
                            //pour trouver son adresse ip, faire ipconfig sur le cmd Windows adresse ipV4
                            PutData putData = new PutData("http://192.168.0.14/connect_caduce/login.php", "POST", field, data);
                            if (putData.startPut()) {
                                if (putData.onComplete()) {
                                    //Fin de la ProgressBar (Setvisibility  View.GONE)
                                    progressBar.setVisibility(View.GONE);
                                    String result = putData.getResult();
                                    //si vous modifiez equals("login success") modifiez aussi
                                    //le echo("login success") de la ligne 8 du fichier login.php
                                    //sinon ça ne pourra pas changer d'activity (ou de page si vous préférez)
                                    if(result.equals("Login Success")){
                                        Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
                                        //Intent permet de lier et de faire communiquer les activity entre elles
                                        //si on arrive à se connecter, on se dirige vers la page principale MainActivity
                                        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                                        startActivity(intent);
                                        //appel de la fonction finish pour mettre un terme à l'activity
                                        finish();
                                    }
                                    else{
                                        //Un toast est une information succincte relative à une opération, qui s'affiche dans une petite fenêtre pop-up
                                        Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }  // fin du if putData.startPut()
                            //Fin de la partie du traitement URL
                        }
                    });
                } //fin du if equals
                else{
                    //sinon tous les champs doivent être remplies
                    //Un toast est une information succincte relative à une opération, qui s'affiche dans une petite fenêtre pop-up
                    Toast.makeText(getApplicationContext(),"Veuillez complétez",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
} //Fin de la classe SignUp

